<div class="col">
                <div class="yit-table style-1 mt-40 table-responsive">
                    <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper no-footer"><table class="table table-hover table-bordered table-striped data-table text-left dataTable no-footer" id="DataTables_Table_0" role="grid">




                    <table class="table table-hover table-bordered table-striped data-table text-left dataTable no-footer" id="DataTables_Table_0" role="grid">
                        <thead class="custom-color-bg-blue text-white">
                            <tr role="row"><th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 173px;" aria-label="Attendee: activate to sort column ascending">Attendee</th>
                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 271px;" aria-label="Company: activate to sort column ascending">Company</th>
                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 166px;" aria-label="City: activate to sort column ascending">City</th>
                            <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 169px;" aria-label="State/Province: activate to sort column ascending">State/Province</th>
                        </tr>
                        </thead>
                        <tbody>
      

                        @foreach($attend_list as $data)
                              
                              <tr>

                                 <td>{{ $data->created_at }}</td>
                                 <td>{{ $data->Attend_status}}</td>
                                 <td>{{ $data->id }}</td>
                                 <td>{{ $data->org_name }}</td>
                        
                             </tr>
                         @endforeach


                           </tbody>
                    </table>





                        </div>
                </div>
            </div>