@extends('Backend/master')

@section('')
@endsection


@section('content')


<div class="yit-cotact-form common-form input-style-1" style="margin-top: 180px;">
            <div class="text-center">
                
                <hr class="style-three  mt-0 mb-4">
            </div>
            <form action="{{ route('update') }}" method="POST">
                @csrf
                <div class="row justify-content-center">
                    <div class="col-md-8 offset-2">
                        <div class="row justify-content-end">

                       

                            <div class="col-12">
                                <div class="form-group control-group">
                                @foreach ($price as $pri)
                                <input type="text" name="amount" value="{{ $pri->amount }}" class="form-control" placeholder="Enter Price">
                                <input type="hidden" name="price_id" value="{{ $pri->id }}">
                                @endforeach
                                </div>
                            </div>
                            
                            <div class="col-xl-3 col-md-3 col-lg-3 col-12">
                            <div style="margin-top: 30px;" class="form-layout-footer mg-t-30 text-center">
                                <button class="btn btn-info mg-r-5">Save</button>
                            </div>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>






<script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    $(document).ready(function(){



      @if(session('success'))
        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: '{{ session('success') }}',
          showConfirmButton: false,
          timer: 1500
        });
        @endif









    });
</script>



@endsection




