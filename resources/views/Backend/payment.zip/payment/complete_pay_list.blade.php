@extends('Backend/master')

@section('list')
@endsection

@section('content')

<div class="row">
                            <div class="col-md-10 offset-2" style="margin-top: 120px;">
                                <div class="card-box table-responsive">

                                <div id="datatable-buttons_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                  
                                


                                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                        <tr>
                                            <th>Reg ID</th>
                                            <th>Name</th>
                                            <th>Transaction ID</th>
                                            <th>Pay Date</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>


                                        <tbody>

                                        @foreach ($pay_list as $list)
                                        <tr>
                                            <td>{{ $list->register_id }}</td>
                                            <td>{{ $list->regis_id->first_name }}</td>
                                            <td>{{ $list->transaction_id }}</td>
                                            <td>{{ $list->created_at }}</td>
                                            <td>{{ $list->price_id }}</td>
                                            <td>
                                            <a href="{{ route('edit-attendee', $list->register_id) }}" class="btn btn-purple">Edit</a>
                                            </td>
                                        </tr>
                                       @endforeach
                                        </tbody>
                                    </table>
                                    </div>
                                </div>
                            </div>
                        </div>

         <script type="text/javascript">
            $(document).ready(function() {
                $('#datatable').DataTable();

                //Buttons examples
                var table = $('#datatable-buttons').DataTable({
                    lengthChange: false,
                    buttons: ['copy', 'excel', 'pdf', 'colvis']
                });

                table.buttons().container()
                        .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
            } );

        </script>


@endsection